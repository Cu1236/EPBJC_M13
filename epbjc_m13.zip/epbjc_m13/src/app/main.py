import sqlite3

# Conectar ao banco de dados
conexao = sqlite3.connect('epbjc.db')
cursor = conexao.cursor()

# Criar a tabela mãe: escola
cursor.execute('''
CREATE TABLE IF NOT EXISTS escola (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL
)
''')

# Criar a tabela professores com relação à tabela escola
cursor.execute('''
CREATE TABLE IF NOT EXISTS professores (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    idade INTEGER NOT NULL,
    escola_id INTEGER NULL,
    FOREIGN KEY (escola_id) REFERENCES escola (id)
)
''')

# Criar a tabela alunos com relação à tabela escola
cursor.execute('''
CREATE TABLE IF NOT EXISTS alunos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    idade INTEGER NOT NULL,
    escola_id INTEGER NULL,
    FOREIGN KEY (escola_id) REFERENCES escola (id)
)
''')

# Criar a tabela material com relação à tabela escola
cursor.execute('''
CREATE TABLE IF NOT EXISTS material (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    marca TEXT NOT NULL,
    escola_id INTEGER NULL,
    FOREIGN KEY (escola_id) REFERENCES escola (id)
)
''')

# Salvar as alterações e fechar a conexão
conexao.commit()
conexao.close()
