import sqlite3
import random
 
conexao = sqlite3.connect('epbjc.db')
cursor = conexao.cursor()

primeiros_nomes = ["Marcelo","Diogo","Sandra","Ines","Carla","Ana","Andre","Helena"]

for i in range (1,21):
    nome_gerado = f"{random.choice(primeiros_nomes)}"
    idade_aleatoria = random.randint(18,69)
    cursor.execute('INSERT INTO professores (nome, idade) VALUES(?, ?)', (nome_gerado, idade_aleatoria))
 
 
conexao.commit()
conexao.close()