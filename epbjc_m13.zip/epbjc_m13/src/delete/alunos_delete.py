import sqlite3

conexao = sqlite3.connect('epbjc.db')
cursor = conexao.cursor()


cursor.execute("DELETE FROM alunos WHERE nome = 'Joel';")
 
conexao.commit()

conexao.close()
 