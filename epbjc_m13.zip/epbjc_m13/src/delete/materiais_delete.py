import sqlite3

conexao = sqlite3.connect('epbjc.db')
cursor = conexao.cursor()


cursor.execute("DELETE FROM materiais WHERE marca = 'note';")
 
conexao.commit()