import sqlite3

conexao = sqlite3.connect('C:\\Users\\Miguel\\OneDrive\\Ambiente de Trabalho\\epbjc_m13\\epbjc.db')
cursor = conexao.cursor()
 
cursor.execute('SELECT * FROM alunos')
 
resultados = cursor.fetchall()
 
for aluno in resultados:
    print(aluno)
 
 
conexao.close()