import sqlite3
 
 
conexao = sqlite3.connect('epbjc.db')
cursor = conexao.cursor()
 
cursor.execute('SELECT * FROM professores')
 
resultados = cursor.fetchall()
 
for professore in resultados:
    print(professore)
 
 
conexao.close()