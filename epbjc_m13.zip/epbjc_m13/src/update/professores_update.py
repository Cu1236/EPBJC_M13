import sqlite3

conexao = sqlite3.connect('epbjc.db')
cursor =  conexao.cursor()

cursor.execute('''UPDATE professores SET nome = "Teste" WHERE id = 3''')

conexao.commit
conexao.close